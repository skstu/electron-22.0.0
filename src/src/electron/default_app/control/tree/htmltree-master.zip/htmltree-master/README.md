# Html tree

A **quick and (very) dirty** experiment to display any website html code as a tree.

# Demo

https://elbywan.github.io/htmltree/

## Uses

- [create-react-app](https://github.com/facebookincubator/create-react-app)
- [bulma](http://bulma.io/)
- [bosket](https://github.com/elbywan/bosket)
- [wretch](https://github.com/elbywan/wretch)